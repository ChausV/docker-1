class VChausController < ApplicationController
  def index
  end
end
