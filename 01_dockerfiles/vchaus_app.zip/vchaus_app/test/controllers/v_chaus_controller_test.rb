require 'test_helper'

class VChausControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get v_chaus_index_url
    assert_response :success
  end

end
